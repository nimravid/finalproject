#!/usr/bin/python
# -*- coding: utf-8 -*-
import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, \
    session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.security import check_password_hash, \
    generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application

app = Flask(__name__)

# Custom filter

app.jinja_env.filters['usd'] = usd

# Configure session to use filesystem (instead of signed cookies)

app.config['SESSION_PERMANENT'] = False
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# Configure CS50 Library to use SQLite database

db = SQL('sqlite:///finance.db')

# Make sure API key is set

if not os.environ.get('API_KEY'):
    raise RuntimeError('API_KEY not set')


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""

    response.headers['Cache-Control'] = \
        'no-cache, no-store, must-revalidate'
    response.headers['Expires'] = 0
    response.headers['Pragma'] = 'no-cache'
    return response


@app.route('/')
@login_required
def index():
    """Show portfolio of stocks"""

    # Check cash

    cash = db.execute('SELECT cash FROM users WHERE id = ?',
                      session['user_id'])[0]['cash']

    # get total value of cash and holdings

    totalAssets = cash

    # Check stocks

    stocks = db.execute(
        'SELECT symbol, SUM(shares) AS shares FROM transactions2 WHERE user_id = ? GROUP BY symbol HAVING SUM(shares) > 0', session['user_id'])
    datas = []
    for stock in stocks:
        data = {}
        price = lookup(stock['symbol'])['price']
        data['symbol'] = stock['symbol']
        data['shares'] = stock['shares']
        data['total'] = stock['shares'] * price
        data['price'] = price
        totalAssets += data['total']
        datas.append(data)
    return render_template('index.html', data=datas, cash=cash,
                           total=totalAssets)


@app.route('/buy', methods=['GET', 'POST'])
@login_required
def buy():
    """Buy shares of stock"""

    if request.method == 'POST':

        # check if symbol enterned

        symbol = request.form.get('symbol')

        if not symbol:
            return apology('This Stock symbol does not exist. Please try again.', 400)

        # get shares from form

        shares = request.form.get('shares')

        # Ensure that shares is an int

        if not shares:
            return apology('must provide shares', 400)

        # Check that shares is int

        try:
            shares = int(shares)
        except:
            return apology('Shares must be an integer number', 400)

        # Ensure that users insert positive amount of shares

        if shares <= 0:
            return apology('must provide positive amount of shares',
                           400)

        # lookup the symbol

        quote = lookup(symbol)

        # checking if ticker is invalid

        if not quote:
            return apology('symbol is invalid', 400)

        # calculate the price of the stock

        price = quote['price'] * shares

        # Check leftover cash

        cash = db.execute('SELECT cash FROM users WHERE id = ?',
                          session['user_id'])

        # valdiate if user has enough cash

        cash = cash[0]['cash']

        if price > cash:
            return apology('The account does not have sufficient funds', 400)

        # Update transactions

        db.execute('INSERT INTO transactions2 (user_id, symbol, price, shares,time_stamp) VALUES (?, ?, ?, ?, datetime())',
                   session['user_id'], symbol, lookup(symbol)['price'], shares)

        # Cash after the purchase

        db.execute('UPDATE users SET cash = ? WHERE id = ?', cash
                   - price, session['user_id'])
        flash('Bought Shares')

        return redirect('/')
    else:

        # GET:

        return render_template('buy.html')


@app.route('/history')
@login_required
def history():
    """Show history of transactions"""

    # Find all transactions made in the past

    portfolio = \
        db.execute('SELECT * FROM transactions2 WHERE user_id = ? ',
                   session['user_id'])

    return render_template('history.html', portfolio=portfolio)


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Log user in"""

    # Forget any user_id

    session.clear()

    # User reached route via POST (as by submitting a form via POST)

    if request.method == 'POST':

        # Ensure username was submitted

        if not request.form.get('username'):
            return apology('must provide username', 400)
        elif not request.form.get('password'):

            # Ensure password was submitted

            return apology('must provide password', 400)

        # Query database for username

        rows = db.execute('SELECT * FROM users WHERE username = ?',
                          request.form.get('username'))

        # Ensure username exists and password is correct

        if len(rows) != 1 or not check_password_hash(rows[0]['hash'],
                                                     request.form.get('password')):
            return apology('invalid username and/or password', 400)

        # Remember which user has logged in

        session['user_id'] = rows[0]['id']

        # Redirect user to home page

        return redirect('/')
    else:

        # User reached route via GET (as by clicking a link or via redirect)

        return render_template('login.html')


@app.route('/logout')
def logout():
    """Log user out"""

    # Forget any user_id

    session.clear()

    # Redirect user to login form

    return redirect('/')


# not sure if that's how you use quote

# Quote: call look up function: takes a stock symbol and returns stock quote

@app.route('/quote', methods=['GET', 'POST'])
@login_required
def quote():
    """Get stock quote."""

    if request.method == 'POST':

        # check if variables is valid

        symbol = request.form.get('symbol')
        if not symbol:
            return apology('This Stock symbol does not exist. Please try again.', 400)

        # use lookup to receive user information

        quote = lookup(symbol)
        if not quote:
            return apology('Invalid Stock', 400)

        return render_template('quoted.html', quote=quote)
    else:

        # GET mehtod:

        return render_template('quote.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Register user"""

    if request.method == 'POST':

        # Ensure that users insert username

        if not request.form.get('username'):
            return apology('must provide username', 400)
        elif not request.form.get('password'):

            # Ensure that users insert password

            return apology('must provide password', 400)
        elif request.form.get('password') != request.form.get('confirmation'):

            # Ensure that password = confirmation

            return apology('Passwords must match. Please try again',
                           400)

        # Ensure that username doesn't exist, login if it doesn't

        try:
            login = \
                db.execute('INSERT INTO users (username, hash) VALUES (?, ?)', request.form.get('username'),
                           generate_password_hash(request.form.get('password')))
        except ValueError:
            return apology('Username already exists', 400)

        # loggin the user in

        session['user_id'] = login

        # tell the user that they're registered

        flash('Registered')
        return redirect('/')
    else:

        # When users just clicked on register

        return render_template('register.html')


@app.route('/sell', methods=['GET', 'POST'])
@login_required
def sell():
    """Sell shares of stock"""

    if request.method == 'POST':

        # check symbol that enterned

        symbol = request.form.get('symbol')

        # Ensure that shares is an int

        if not request.form.get('shares'):
            return apology('must provide shares', 400)
        sharestosell = request.form.get('shares')
        sharestosell = int(sharestosell)

        user_shares = \
            db.execute('SELECT SUM(shares) as shares FROM transactions2 WHERE user_id = ?', session['user_id'])

        # Ensure that users insert positive amount of shares

        if sharestosell <= 0:
            return apology('must be pos', 400)
        print('user_shares is ', user_shares)
        if sharestosell > user_shares[0]['shares']:
            return apology('The account does not have sufficient funds', 400)

        # Update shares

        db.execute('INSERT INTO transactions2 (user_id, symbol, price, shares, time_stamp) VALUES (?, ?, ?, ?, datetime())', session['user_id'], symbol, lookup(symbol)['price'
                                                                                                                                                                        ], -sharestosell)

        # calculate the profit made from selling the shares

        profit = lookup(symbol)['price'] * sharestosell

        # Check cash

        cash = db.execute('SELECT cash FROM users WHERE id = ?',
                          session['user_id'])

        # Cash after the purchase

        db.execute('UPDATE users SET cash = ? WHERE id = ?',
                   cash[0]['cash'] + profit, session['user_id'])
        flash('Sold Shares')
        return redirect('/')
    else:

        # GET:
        transactions = db.execute(
            'SELECT symbol from transactions2 where user_id = ? GROUP BY symbol HAVING SUM(shares) > 0', session['user_id'])
        return render_template('sell.html', symbols=transactions)


# personal touch: add money

@app.route('/addmoney', methods=['GET', 'POST'])
def addmoney():
    """Add Money"""

    if request.method == 'POST':

        # Check cash

        cash = db.execute('SELECT cash FROM users WHERE id = ?',
                          session['user_id'])

        # amount the user input

        newmoney = request.form.get('amount')
        try:
            newmoney = int(newmoney)
            if newmoney <= 0:
                return apology('money must be a positive number', 400)
        except:
            return apology('money must be an integer', 400)

        # Cash after the purchase

        db.execute('UPDATE users SET cash = ? WHERE id = ?',
                   cash[0]['cash'] + newmoney, session['user_id'])
        flash('Money added!')
        return redirect('/')

    # GET:

    return render_template('addmoney.html')